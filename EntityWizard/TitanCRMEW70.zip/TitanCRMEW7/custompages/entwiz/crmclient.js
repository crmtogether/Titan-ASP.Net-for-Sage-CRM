

function Defined(Arg)
{
	return (Arg+""!="undefined");
}
