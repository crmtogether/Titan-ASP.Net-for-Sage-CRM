
<%
   // CRM Constants
   var iKey_CompanyId		=1;
   var iKey_PersonId		=2;
   var iKey_AddressId		=3;
   var iKey_UserId		=4;
   var iKey_ChannelId		=5;
   var iKey_CommunicationId	=6;
   var iKey_OpportunityId	=7;
   var iKey_CaseId		=8;
   var iKey_NoteId		=9;
   var iKey_TeamId		=10;
   var iKey_UserAdminId		=11;
   var iKey_ChannelAdminId	=12;
   var iKey_LockId		=13;
   var iKey_TranslationId	=14;
   var iKey_LibraryId		=15;
   var iKey_ProductId		=16;
   var iKey_CaseProgressId	=17;
   var iKey_OpportunityProgressId=18;
   var iKey_CompanySearchKey	=19;
   var iKey_PersonSearchKey	=20;
   var iKey_OpportunitySearchKey=21;
   var iKey_CaseSearchKey	=22;
   var iKey_CommSearchKey	=23;
   var iKey_LeadId		=44;
   var iKey_AccountId		=24;
   var iKey_OrderId		=71;
   var iKey_QuoteId		=86;

%>

